# Android APK build

This project is packaged as a Capacitor Android shell around the deployed TanStack Start application.

## Why the APK loads the deployed app

The application uses TanStack Start server functions and server-side Supabase operations. Those server functions cannot be converted into a static APK bundle. The Android shell therefore loads the production web application and keeps the server/backend online.

Default production URL:

`https://palm-sync-pro.lovable.app`

To use another deployment, set the Capacitor environment variable `CAPACITOR_SERVER_URL` before `npx cap sync android`.

## Local build

Requirements:
- Node.js 22+
- Java 21
- Android SDK

Commands:

```bash
npm install
npm run android:add
npm run android:sync
cd android
./gradlew assembleDebug
```

APK:

`android/app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions

Push this project to GitHub and run **Actions → Build Android APK**. The workflow creates the Android project, builds the debug APK, and uploads it as an artifact.
