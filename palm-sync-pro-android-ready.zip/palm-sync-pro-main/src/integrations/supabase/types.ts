export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.17"
  }
  public: {
    Tables: {
      app_access: {
        Row: {
          code_hash: string
          id: number
          updated_at: string
        }
        Insert: {
          code_hash: string
          id?: number
          updated_at?: string
        }
        Update: {
          code_hash?: string
          id?: number
          updated_at?: string
        }
        Relationships: []
      }
      app_settings: {
        Row: {
          id: number
          sheet_synced_at: string | null
          spreadsheet_id: string | null
          updated_at: string
        }
        Insert: {
          id?: number
          sheet_synced_at?: string | null
          spreadsheet_id?: string | null
          updated_at?: string
        }
        Update: {
          id?: number
          sheet_synced_at?: string | null
          spreadsheet_id?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      audit_log: {
        Row: {
          batch_id: string | null
          detail: Json | null
          event_type: string
          id: number
          occurred_at: string
          order_number: string | null
        }
        Insert: {
          batch_id?: string | null
          detail?: Json | null
          event_type: string
          id?: number
          occurred_at?: string
          order_number?: string | null
        }
        Update: {
          batch_id?: string | null
          detail?: Json | null
          event_type?: string
          id?: number
          occurred_at?: string
          order_number?: string | null
        }
        Relationships: []
      }
      batches: {
        Row: {
          code: string
          created_at: string
          id: string
          status: Database["public"]["Enums"]["batch_status"]
          validated_at: string | null
        }
        Insert: {
          code: string
          created_at?: string
          id?: string
          status?: Database["public"]["Enums"]["batch_status"]
          validated_at?: string | null
        }
        Update: {
          code?: string
          created_at?: string
          id?: string
          status?: Database["public"]["Enums"]["batch_status"]
          validated_at?: string | null
        }
        Relationships: []
      }
      orders: {
        Row: {
          batch_id: string
          id: string
          order_number: string
          scanned_at: string
          validated_at: string | null
        }
        Insert: {
          batch_id: string
          id?: string
          order_number: string
          scanned_at?: string
          validated_at?: string | null
        }
        Update: {
          batch_id?: string
          id?: string
          order_number?: string
          scanned_at?: string
          validated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "orders_batch_id_fkey"
            columns: ["batch_id"]
            isOneToOne: false
            referencedRelation: "batches"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      add_scan: {
        Args: { p_batch_id: string; p_order_number: string }
        Returns: Json
      }
      add_scan_to_batch: {
        Args: { p_batch_id: string; p_order_number: string; p_source?: string }
        Returns: Json
      }
      batch_orders: { Args: { p_batch_id: string }; Returns: Json }
      day_summary: { Args: { p_day: string }; Returns: Json }
      delete_batch: {
        Args: { p_batch_id: string; p_reason?: string }
        Returns: Json
      }
      delete_order: {
        Args: { p_order_id: string; p_reason?: string }
        Returns: Json
      }
      recent_days: { Args: { p_limit?: number }; Returns: Json }
      start_batch: {
        Args: never
        Returns: {
          code: string
          created_at: string
          id: string
          status: Database["public"]["Enums"]["batch_status"]
          validated_at: string | null
        }
        SetofOptions: {
          from: "*"
          to: "batches"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      undo_last_scan: { Args: { p_batch_id: string }; Returns: Json }
      validate_batch: { Args: { p_batch_id: string }; Returns: Json }
    }
    Enums: {
      batch_status: "open" | "validated"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      batch_status: ["open", "validated"],
    },
  },
} as const
