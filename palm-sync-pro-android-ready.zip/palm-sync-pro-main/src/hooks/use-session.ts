import { useCallback, useEffect, useState } from "react";

const KEY = "ott.session";

export function readToken(): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(KEY);
}

export function useSession() {
  const [token, setToken] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setToken(readToken());
    setReady(true);
  }, []);

  const save = useCallback((value: string) => {
    window.localStorage.setItem(KEY, value);
    setToken(value);
  }, []);

  const clear = useCallback(() => {
    window.localStorage.removeItem(KEY);
    setToken(null);
  }, []);

  return { token, ready, save, clear };
}

export function useOnline() {
  const [online, setOnline] = useState(true);

  useEffect(() => {
    const update = () => setOnline(navigator.onLine);
    update();
    window.addEventListener("online", update);
    window.addEventListener("offline", update);
    return () => {
      window.removeEventListener("online", update);
      window.removeEventListener("offline", update);
    };
  }, []);

  return online;
}
