import { useCallback, useRef } from "react";

/**
 * Multi-sensory scan feedback: distinct tones + haptics for accept vs reject.
 * Audio is created lazily on first use so the PDA browser allows playback.
 */
export function useScanFeedback() {
  const ctxRef = useRef<AudioContext | null>(null);

  const tone = useCallback((freqs: number[], duration: number) => {
    try {
      if (!ctxRef.current) {
        const Ctor =
          window.AudioContext ??
          (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (!Ctor) return;
        ctxRef.current = new Ctor();
      }
      const ctx = ctxRef.current;
      void ctx.resume();
      freqs.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "square";
        osc.frequency.value = freq;
        const start = ctx.currentTime + i * duration;
        gain.gain.setValueAtTime(0.001, start);
        gain.gain.exponentialRampToValueAtTime(0.25, start + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.001, start + duration);
        osc.connect(gain).connect(ctx.destination);
        osc.start(start);
        osc.stop(start + duration);
      });
    } catch {
      /* audio unavailable — visual + haptic feedback still applies */
    }
  }, []);

  const vibrate = useCallback((pattern: number | number[]) => {
    try {
      navigator.vibrate?.(pattern);
    } catch {
      /* no haptics on this device */
    }
  }, []);

  const accept = useCallback(() => {
    tone([1320], 0.07);
    vibrate(45);
  }, [tone, vibrate]);

  const reject = useCallback(() => {
    tone([220, 165], 0.16);
    vibrate([120, 70, 220]);
  }, [tone, vibrate]);

  return { accept, reject };
}
