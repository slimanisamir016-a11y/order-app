import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";

import {
  discardEmptyBatch,
  getDaySummary,
  getOpenBatch,
  getSheetLink,
  startBatch,
  syncSheet,
  unlockDevice,
} from "@/lib/ott.functions";
import { useOnline, useSession } from "@/hooks/use-session";


export const Route = createFileRoute("/")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Order Traceability Tool — Scan orders into bags" },
      {
        name: "description",
        content:
          "Warehouse outbound tool: scan orders into a shipping bag, reject duplicates, and seal the bag with a permanent, immutable record.",
      },
      { property: "og:title", content: "Order Traceability Tool" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      {
        property: "og:description",
        content: "Scan orders into shipping bags and seal them with a permanent record.",
      },
    ],
  }),
  component: HomeScreen,
});

const STALE_HOURS = 8;

function HomeScreen() {
  const { token, ready, save, clear } = useSession();
  const online = useOnline();
  const navigate = useNavigate();

  const unlock = useServerFn(unlockDevice);
  const fetchOpen = useServerFn(getOpenBatch);
  const start = useServerFn(startBatch);
  const discardEmpty = useServerFn(discardEmptyBatch);
  const daySummary = useServerFn(getDaySummary);
  const runSync = useServerFn(syncSheet);
  const sheetLink = useServerFn(getSheetLink);

  const [code, setCode] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [syncNote, setSyncNote] = useState<string | null>(null);
  const [sheetUrl, setSheetUrl] = useState<string | null>(null);
  const [dayTotal, setDayTotal] = useState(0);
  const [batch, setBatch] = useState<{
    id: string;
    code: string;
    created_at: string;
    count: number;
  } | null>(null);
  const [loaded, setLoaded] = useState(false);
  const codeRef = useRef<HTMLInputElement>(null);

  const refresh = useCallback(
    async (t: string, withCleanup = false) => {
      try {
        const [res, day] = await Promise.all([
          fetchOpen({ data: { token: t } }),
          daySummary({ data: { token: t, day: new Date().toISOString().slice(0, 10) } }),
        ]);
        let openBatch = res.batch;
        // A bag with zero orders is never kept: clean up any lingering empty
        // bag left behind by a closed session before the worker can resume it.
        if (withCleanup && openBatch && openBatch.count === 0) {
          try {
            await discardEmpty({ data: { token: t, batchId: openBatch.id } });
            openBatch = null;
          } catch {
            // Best-effort; the worker can still resume and discard from the bag screen.
          }
        }
        setBatch(openBatch);
        setDayTotal(day.total);
        setLoaded(true);
      } catch {
        clear();
        setLoaded(true);
      }
    },
    [fetchOpen, daySummary, clear, discardEmpty],
  );

  useEffect(() => {
    if (ready && token) void refresh(token, true);
    if (ready && !token) setLoaded(true);
  }, [ready, token, refresh]);

  useEffect(() => {
    if (!token) return;
    void sheetLink({ data: { token } })
      .then((r) => setSheetUrl(r.url))
      .catch(() => undefined);
  }, [token, sheetLink]);

  // Continuous two-way sync with the Google Sheet: on load, on a short timer,
  // and whenever the device comes back to the foreground or back online.
  useEffect(() => {
    if (!token || !online) return;
    let running = false;
    let stopped = false;
    let nextSyncAt = 0;
    const tick = () => {
      if (running || stopped || document.hidden || Date.now() < nextSyncAt) return;
      running = true;
      nextSyncAt = Date.now() + 60_000;
      void runSync({ data: { token } })
        .then((result) => {
          nextSyncAt = Math.max(nextSyncAt, result.retryAt ?? 0);
          if (!result.ok) setSyncNote(result.message ?? "Sheet sync unavailable");
          return refresh(token);
        })
        .catch(() => undefined)
        .finally(() => {
          running = false;
        });
    };
    tick();
    const id = window.setInterval(tick, 60_000);
    document.addEventListener("visibilitychange", tick);
    window.addEventListener("focus", tick);
    window.addEventListener("online", tick);
    return () => {
      stopped = true;
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", tick);
      window.removeEventListener("focus", tick);
      window.removeEventListener("online", tick);
    };
  }, [token, online, runSync, refresh]);


  async function handleSync() {
    if (!token || syncing || !online) return;
    setSyncing(true);
    setSyncNote(null);
    try {
      const res = await runSync({ data: { token } });
      await refresh(token);
      setSyncNote(
        res.ok ? `Sheet synced — ${res.added} added, ${res.removed} removed` : res.message ?? "No sheet linked",
      );
    } catch {
      setSyncNote("Sheet sync failed");
    } finally {
      setSyncing(false);
    }
  }


  useEffect(() => {
    if (ready && !token) codeRef.current?.focus();
  }, [ready, token]);

  async function handleUnlock(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    setError(null);
    try {
      const res = await unlock({ data: { code } });
      if (!res.ok) {
        setError("That code isn't right. Try again.");
        setCode("");
      } else {
        save(res.token);
      }
    } catch {
      setError("No connection. Check the network and try again.");
    } finally {
      setBusy(false);
    }
  }

  async function handleStart() {
    if (!token || busy) return;
    setBusy(true);
    try {
      const res = await start({ data: { token } });
      void navigate({ to: "/batch", search: { id: res.batch.id } });
    } catch {
      setError("Couldn't start a bag. Check the connection.");
      setBusy(false);
    }
  }

  if (!ready) return <div className="min-h-screen bg-background" />;

  if (!token) {
    return (
      <main className="flex min-h-screen flex-col items-center justify-center gap-8 px-6">
        <header className="text-center">
          <p className="label-caps">Outbound</p>
          <h1 className="display text-5xl font-bold uppercase">Order Traceability</h1>
        </header>
        <form onSubmit={handleUnlock} className="w-full max-w-sm space-y-4">
          <label className="label-caps block" htmlFor="access-code">
            Access code
          </label>
          <input
            id="access-code"
            ref={codeRef}
            type="password"
            inputMode="numeric"
            autoComplete="off"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="h-20 w-full rounded-2xl border border-border bg-surface px-5 text-center font-mono text-4xl tracking-[0.4em] text-foreground outline-none focus:border-ring"
          />
          {error ? (
            <p className="rounded-2xl bg-destructive px-4 py-3 text-center text-lg font-bold text-destructive-foreground">
              {error}
            </p>
          ) : null}
          <button type="submit" disabled={busy} className="pad-button pad-button-primary w-full">
            Unlock
          </button>
        </form>
      </main>
    );
  }

  const ageHours = batch ? (Date.now() - new Date(batch.created_at).getTime()) / 3_600_000 : 0;

  return (
    <main className="mx-auto flex min-h-screen w-full max-w-2xl flex-col gap-8 px-6 py-8">
      <header className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4">
        <div className="min-w-0">
          <p className="label-caps">Outbound</p>
          <h1 className="display truncate text-4xl font-bold uppercase">Order Traceability</h1>
        </div>
        <button
          onClick={clear}
          className="label-caps shrink-0 rounded-full border border-border px-3 py-2"
        >
          Lock
        </button>
      </header>

      {!online ? (
        <p className="rounded-2xl bg-destructive px-4 py-4 text-center text-xl font-bold text-destructive-foreground">
          No connection — scanning is blocked until the device is back online.
        </p>
      ) : null}

      <section className="soft-card p-6 text-center">
        <p className="label-caps">Scanned today</p>
        <p className="display text-7xl font-bold leading-none tabular-nums text-primary">
          {dayTotal}
        </p>
      </section>



      {!loaded ? (
        <p className="label-caps">Checking for an open bag…</p>
      ) : batch ? (
        <section className="space-y-5">
          <div className="soft-card p-6">
            <p className="label-caps">Bag in progress</p>
            <p className="display mt-1 font-mono text-3xl font-bold text-primary">{batch.code}</p>
            <p className="display mt-4 text-7xl font-bold leading-none">{batch.count}</p>
            <p className="label-caps mt-1">Orders inside</p>
            {ageHours > STALE_HOURS ? (
              <p className="mt-5 rounded-2xl bg-warning px-4 py-3 text-base font-bold text-warning-foreground">
                This bag has been open for {Math.floor(ageHours)} hours. Seal it or check with the
                shift lead before adding more.
              </p>
            ) : null}
          </div>
          <button
            onClick={() => navigate({ to: "/batch", search: { id: batch.id } })}
            disabled={!online}
            className="pad-button pad-button-primary w-full disabled:opacity-40"
          >
            Resume bag
          </button>
        </section>
      ) : (
        <section className="space-y-5">
          <div className="rounded-xl border-2 border-dashed border-border p-8 text-center">
            <p className="display text-3xl font-bold uppercase">No bag open</p>
            <p className="mt-2 text-muted-foreground">Start a new bag to begin scanning.</p>
          </div>
          <button
            onClick={handleStart}
            disabled={busy || !online}
            className="pad-button pad-button-primary w-full disabled:opacity-40"
          >
            Start new bag
          </button>
        </section>
      )}

      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={() => navigate({ to: "/history" })}
          className="label-caps rounded-2xl border border-border py-4"
        >
          Daily log
        </button>
        <button
          onClick={handleSync}
          disabled={syncing || !online}
          className="label-caps rounded-2xl border border-border py-4 disabled:opacity-40"
        >
          {syncing ? "Syncing…" : "Sync sheet"}
        </button>
      </div>

      {sheetUrl ? (
        <a
          href={sheetUrl}
          target="_blank"
          rel="noreferrer"
          className="label-caps rounded-2xl border border-border py-4 text-center"
        >
          Open Google Sheet log
        </a>
      ) : null}

      {syncNote ? <p className="label-caps text-center">{syncNote}</p> : null}

      {error ? (
        <p className="rounded-2xl bg-destructive px-4 py-3 text-center font-bold text-destructive-foreground">
          {error}
        </p>
      ) : null}

    </main>
  );
}
