import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useCallback, useEffect, useRef, useState } from "react";
import { z } from "zod";

import {
  deleteOrder,
  discardEmptyBatch,
  getBatchOrders,
  getOpenBatch,
  scanOrder,
  syncSheet,
  undoLastScan,
  validateBatch,
} from "@/lib/ott.functions";
import { useOnline, useSession } from "@/hooks/use-session";
import { useScanFeedback } from "@/hooks/use-scan-feedback";

export const Route = createFileRoute("/batch")({
  ssr: false,
  validateSearch: (search) => z.object({ id: z.string().uuid().optional() }).parse(search),
  head: () => ({
    meta: [
      { title: "Scanning bag — Order Traceability Tool" },
      {
        name: "description",
        content:
          "Scan six-digit orders into the open shipping bag. Duplicates are rejected instantly and the bag is sealed on validation.",
      },
      { property: "og:title", content: "Scanning bag — Order Traceability Tool" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      {
        property: "og:description",
        content: "Scan orders into the open shipping bag with instant duplicate rejection.",
      },
    ],
  }),
  component: BatchScreen,
});

type Feedback = { kind: "accept" | "reject" | "undo"; message: string; at: number } | null;
type OrderRow = { id: string; order_number: string; scanned_at: string };

function BatchScreen() {
  const { token, ready } = useSession();
  const online = useOnline();
  const navigate = useNavigate();
  const feedbackSound = useScanFeedback();

  const fetchOpen = useServerFn(getOpenBatch);
  const scan = useServerFn(scanOrder);
  const undo = useServerFn(undoLastScan);
  const validate = useServerFn(validateBatch);
  const removeOrder = useServerFn(deleteOrder);
  const discardEmpty = useServerFn(discardEmptyBatch);
  const listOrders = useServerFn(getBatchOrders);
  const runSync = useServerFn(syncSheet);

  const [batch, setBatch] = useState<{ id: string; code: string; count: number } | null>(null);
  const [count, setCount] = useState(0);
  const [orders, setOrders] = useState<OrderRow[]>([]);
  const [listOpen, setListOpen] = useState(false);
  const [feedback, setFeedback] = useState<Feedback>(null);
  const [confirming, setConfirming] = useState(false);
  const [pendingDelete, setPendingDelete] = useState<OrderRow | null>(null);
  const [manual, setManual] = useState("");
  const [busy, setBusy] = useState(false);
  const [syncing, setSyncing] = useState(false);

  const scanRef = useRef<HTMLInputElement>(null);
  const cancelRef = useRef<HTMLButtonElement>(null);

  const refreshCounts = useCallback(
    async (batchId: string, t: string) => {
      const rows = await listOrders({ data: { token: t, batchId } });
      setOrders(rows);
      setCount(rows.length);
    },
    [listOrders],
  );

  useEffect(() => {
    if (!ready) return;
    if (!token) {
      void navigate({ to: "/" });
      return;
    }
    void fetchOpen({ data: { token } })
      .then((res) => {
        if (!res.batch) {
          void navigate({ to: "/" });
          return;
        }
        setBatch(res.batch);
        setCount(res.batch.count);
        void refreshCounts(res.batch.id, token);
      })
      .catch(() => navigate({ to: "/" }));
  }, [ready, token, fetchOpen, navigate, refreshCounts]);

  // Continuous two-way sync with the Google Sheet: on load, on a short timer,
  // and whenever the device comes back to the foreground or back online.
  useEffect(() => {
    if (!token || !batch || !online) return;
    let running = false;
    let stopped = false;
    let nextSyncAt = 0;
    const tick = () => {
      if (running || stopped || document.hidden || Date.now() < nextSyncAt) return;
      running = true;
      nextSyncAt = Date.now() + 60_000;
      void runSync({ data: { token } })
        .then((result) => {
          nextSyncAt = Math.max(nextSyncAt, result.retryAt ?? 0);
          return refreshCounts(batch.id, token);
        })
        .catch(() => undefined)
        .finally(() => {
          running = false;
        });
    };
    tick();
    const id = window.setInterval(tick, 60_000);
    document.addEventListener("visibilitychange", tick);
    window.addEventListener("focus", tick);
    window.addEventListener("online", tick);
    return () => {
      stopped = true;
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", tick);
      window.removeEventListener("focus", tick);
      window.removeEventListener("online", tick);
    };
  }, [token, batch, online, runSync, refreshCounts]);


  // Keyboard-wedge focus guard: the hidden input must always be ready for the trigger.
  const restoreFocus = useCallback(() => {
    if (confirming || listOpen) return;
    if (document.activeElement !== scanRef.current) scanRef.current?.focus();
  }, [confirming, listOpen]);

  useEffect(() => {
    restoreFocus();
    const id = window.setInterval(restoreFocus, 400);
    window.addEventListener("click", restoreFocus);
    window.addEventListener("focus", restoreFocus);
    document.addEventListener("visibilitychange", restoreFocus);
    return () => {
      window.clearInterval(id);
      window.removeEventListener("click", restoreFocus);
      window.removeEventListener("focus", restoreFocus);
      document.removeEventListener("visibilitychange", restoreFocus);
    };
  }, [restoreFocus]);

  useEffect(() => {
    if (confirming) cancelRef.current?.focus();
  }, [confirming]);

  const submitCode = useCallback(
    async (raw: string) => {
      const value = raw.trim();
      if (!value || !token || !batch) return;
      if (!online) {
        feedbackSound.reject();
        setFeedback({ kind: "reject", message: "Offline — scan not saved", at: Date.now() });
        return;
      }
      if (!/^\d{6}$/.test(value)) {
        feedbackSound.reject();
        setFeedback({ kind: "reject", message: `${value} — must be 6 digits`, at: Date.now() });
        return;
      }
      try {
        const res = await scan({ data: { token, batchId: batch.id, orderNumber: value } });
        if (res.result === "accepted") {
          setCount(res.count);
          setOrders((prev) => [
            { id: `tmp-${value}`, order_number: value, scanned_at: new Date().toISOString() },
            ...prev,
          ]);
          feedbackSound.accept();
          setFeedback({ kind: "accept", message: value, at: Date.now() });
          void refreshCounts(batch.id, token);
        } else if (res.result === "bad_format") {
          feedbackSound.reject();
          setFeedback({ kind: "reject", message: `${value} — must be 6 digits`, at: Date.now() });
        } else {
          feedbackSound.reject();
          setFeedback({
            kind: "reject",
            message:
              res.same_batch === false
                ? `${value} — already in another bag`
                : `${value} — already in this bag`,
            at: Date.now(),
          });
        }
      } catch {
        feedbackSound.reject();
        setFeedback({ kind: "reject", message: "Not saved — connection lost", at: Date.now() });
      }
    },
    [token, batch, online, scan, feedbackSound, refreshCounts],
  );

  async function handleUndo() {
    if (!token || !batch || busy || !online) return;
    setBusy(true);
    try {
      const res = await undo({ data: { token, batchId: batch.id } });
      setFeedback({
        kind: "undo",
        message: res.result === "undone" ? `Removed ${res.order_number}` : "Bag is already empty",
        at: Date.now(),
      });
      await refreshCounts(batch.id, token);
    } catch {
      setFeedback({ kind: "reject", message: "Undo failed — connection lost", at: Date.now() });
    } finally {
      setBusy(false);
    }
  }

  async function handleDelete(order: OrderRow) {
    if (!token || !batch || busy || !online) return;
    setBusy(true);
    try {
      await removeOrder({ data: { token, orderId: order.id } });
      setPendingDelete(null);
      await refreshCounts(batch.id, token);
      setFeedback({ kind: "undo", message: `Deleted ${order.order_number}`, at: Date.now() });
    } catch {
      setFeedback({ kind: "reject", message: "Delete failed — try again", at: Date.now() });
    } finally {
      setBusy(false);
    }
  }

  async function handleSync() {
    if (!token || !batch || syncing || !online) return;
    setSyncing(true);
    try {
      const res = await runSync({ data: { token } });
      await refreshCounts(batch.id, token);
      setFeedback({
        kind: "undo",
        message: res.ok
          ? `Sheet synced — ${res.added} added, ${res.removed} removed`
          : res.message ?? "No sheet linked",
        at: Date.now(),
      });
    } catch {
      setFeedback({ kind: "reject", message: "Sheet sync failed", at: Date.now() });
    } finally {
      setSyncing(false);
    }
  }

  // A bag with zero orders is never saved: leaving it empty discards it.
  async function goHome() {
    if (batch && count === 0 && token && online) {
      try {
        await discardEmpty({ data: { token, batchId: batch.id } });
      } catch {
        // Discarding is best-effort; Home cleans up any lingering empty bag.
      }
    }
    navigate({ to: "/" });
  }

  async function handleValidate() {
    if (!token || !batch || busy) return;
    if (count === 0) {
      feedbackSound.reject();
      setFeedback({ kind: "reject", message: "Bag is empty — scan at least one order", at: Date.now() });
      return;
    }
    setBusy(true);
    try {
      await validate({ data: { token, batchId: batch.id } });
      setConfirming(false);
      void navigate({ to: "/" });
    } catch {
      setFeedback({ kind: "reject", message: "Sealing failed — try again", at: Date.now() });
      setBusy(false);
      setConfirming(false);
    }
  }

  if (!batch) return <div className="min-h-screen bg-background" />;

  const rejected = feedback?.kind === "reject";

  return (
    <main className="mx-auto flex min-h-screen w-full max-w-2xl flex-col gap-5 px-4 py-5">
      <header className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
        <div className="min-w-0">
          <p className="label-caps">Bag</p>
          <p className="display truncate font-mono text-2xl font-bold text-primary">{batch.code}</p>
        </div>
        <span
          className={`label-caps shrink-0 rounded-full px-3 py-2 ${online ? "border border-border" : "bg-destructive text-destructive-foreground"}`}
        >
          {online ? "Online" : "Offline"}
        </span>
      </header>

      {!online ? (
        <p className="rounded-2xl bg-destructive px-4 py-3 text-center text-lg font-bold text-destructive-foreground">
          Connection lost — scanning is blocked until it returns.
        </p>
      ) : null}

      <section className="soft-card px-4 py-6 text-center">
        <p className="label-caps">In this bag</p>
        <p className="display text-[6rem] font-bold leading-none tabular-nums">{count}</p>
      </section>

      {/* Visible capture field — the keyboard-wedge scanner types here (ends with Enter),
          and workers can also type a damaged-label order by hand. */}
      <input
        ref={scanRef}
        autoFocus
        value={manual}
        inputMode="numeric"
        autoComplete="off"
        placeholder="Scan or type order…"
        disabled={!online}
        className="h-16 w-full rounded-2xl border border-border bg-surface px-4 text-center font-mono text-2xl tracking-widest text-foreground outline-none focus:border-ring disabled:opacity-40"
        onChange={(e) => setManual(e.target.value.replace(/\D/g, "").slice(0, 6))}
        onKeyDown={(e) => {
          if (e.key !== "Enter" && e.key !== "Tab") return;
          e.preventDefault();
          const value = manual;
          setManual("");
          void submitCode(value);
        }}
      />

      <section
        key={feedback?.at ?? "idle"}
        className={`flex min-h-28 flex-col items-center justify-center rounded-xl px-4 py-5 text-center ${
          rejected
            ? "bg-destructive text-destructive-foreground"
            : feedback?.kind === "accept"
              ? "feedback-accept text-foreground"
              : "bg-surface text-muted-foreground"
        }`}
      >
        {feedback ? (
          <>
            <p className="display text-3xl font-bold uppercase">
              {feedback.kind === "accept"
                ? "Added"
                : feedback.kind === "undo"
                  ? "Done"
                  : "Rejected"}
            </p>
            <p className="mt-1 font-mono text-lg break-all">{feedback.message}</p>
          </>
        ) : (
          <p className="display text-3xl font-bold uppercase">Ready to scan</p>
        )}
      </section>

      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={handleUndo}
          disabled={busy || !online}
          className="pad-button pad-button-secondary disabled:opacity-40"
        >
          Undo last
        </button>
        <button
          onClick={() => {
            if (count === 0) {
              feedbackSound.reject();
              setFeedback({ kind: "reject", message: "Bag is empty — scan at least one order", at: Date.now() });
              return;
            }
            setConfirming(true);
          }}
          className="pad-button pad-button-primary"
          disabled={busy}
        >
          Validate
        </button>
      </div>

      <button
        onClick={() => setListOpen((v) => !v)}
        className="label-caps rounded-2xl border border-border py-4"
      >
        {listOpen ? "Hide orders" : `Show orders (${count})`}
      </button>

      {listOpen ? (
        <ul className="divide-y divide-border overflow-hidden rounded-2xl border border-border">
          {orders.length === 0 ? (
            <li className="px-4 py-4 text-muted-foreground">Nothing scanned yet.</li>
          ) : (
            orders.map((o) => (
              <li key={o.id} className="grid grid-cols-[1fr_auto] items-center gap-3 px-4 py-3">
                <span className="font-mono text-xl">{o.order_number}</span>
                <button
                  onClick={() => setPendingDelete(o)}
                  disabled={busy || !online}
                  className="label-caps rounded-full bg-destructive px-4 py-3 text-destructive-foreground disabled:opacity-40"
                >
                  Delete
                </button>
              </li>
            ))
          )}
        </ul>
      ) : null}


      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={handleSync}
          disabled={syncing || !online}
          className="label-caps rounded-2xl border border-border py-4 disabled:opacity-40"
        >
          {syncing ? "Syncing…" : "Sync sheet"}
        </button>
        <button
          onClick={goHome}
          className="label-caps rounded-2xl border border-border py-4"
        >
          Home
        </button>
      </div>

      {pendingDelete ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/90 px-5">
          <div className="soft-card w-full max-w-md p-6 text-center">
            <p className="label-caps">Delete this order</p>
            <p className="display mt-1 font-mono text-3xl font-bold text-primary">
              {pendingDelete.order_number}
            </p>
            <p className="mt-4 text-muted-foreground">
              This permanently removes the order from bag {batch.code} and from the Google Sheet.
              This cannot be undone.
            </p>
            <div className="mt-6 grid gap-3">
              <button
                autoFocus
                onClick={() => {
                  setPendingDelete(null);
                  window.setTimeout(restoreFocus, 0);
                }}
                className="pad-button pad-button-secondary w-full"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDelete(pendingDelete)}
                disabled={busy || !online}
                className="pad-button pad-button-danger w-full disabled:opacity-40"
              >
                {busy ? "Deleting…" : "Delete order"}
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {confirming ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/90 px-5">
          <div className="w-full max-w-md soft-card p-6 text-center">
            <p className="label-caps">Seal this bag</p>
            <p className="display mt-1 font-mono text-2xl font-bold text-primary">{batch.code}</p>
            <p className="display mt-4 text-6xl font-bold leading-none">{count}</p>
            <p className="label-caps mt-1">Orders will be frozen</p>
            <p className="mt-4 text-muted-foreground">
              Once sealed, nothing more can be scanned into this bag.
            </p>
            <div className="mt-6 grid gap-3">
              {/* Cancel is auto-focused so a stray scanner Enter cancels instead of sealing. */}
              <button
                ref={cancelRef}
                onClick={() => {
                  setConfirming(false);
                  window.setTimeout(restoreFocus, 0);
                }}
                className="pad-button pad-button-secondary w-full"
              >
                Cancel
              </button>
              <button
                onClick={handleValidate}
                disabled={busy || !online}
                className="pad-button w-full bg-success text-success-foreground disabled:opacity-40"
              >
                Confirm seal
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </main>
  );
}
