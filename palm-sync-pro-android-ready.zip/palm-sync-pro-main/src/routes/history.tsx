import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useCallback, useEffect, useState } from "react";

import {
  deleteBatch,
  deleteOrder,
  getBatchOrders,
  getDaySummary,
  getSheetLink,
  searchOrders,
} from "@/lib/ott.functions";
import { useOnline, useSession } from "@/hooks/use-session";

export const Route = createFileRoute("/history")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Daily log — Order Traceability Tool" },
      {
        name: "description",
        content:
          "Browse every bag and scanned order day by day, search any order number, and keep permanent records well beyond 30 days.",
      },
      { property: "og:title", content: "Daily log — Order Traceability Tool" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      {
        property: "og:description",
        content: "Day-by-day totals, bag records, and order search for outbound scanning.",
      },
    ],
  }),
  component: HistoryScreen,
});

type Bag = {
  id: string;
  code: string;
  status: "open" | "validated";
  created_at: string;
  validated_at: string | null;
  count: number;
};
type OrderRow = { id: string; order_number: string; scanned_at: string };
type Hit = {
  id: string;
  order_number: string;
  scanned_at: string;
  bag_code: string;
  bag_status: string;
};
type Confirm =
  | { kind: "order"; id: string; label: string; bagLabel?: string }
  | { kind: "bag"; id: string; label: string; count: number }
  | null;

const todayISO = () => new Date().toISOString().slice(0, 10);

function HistoryScreen() {
  const { token, ready } = useSession();
  const online = useOnline();
  const navigate = useNavigate();

  const daySummary = useServerFn(getDaySummary);
  const listOrders = useServerFn(getBatchOrders);
  const removeOrder = useServerFn(deleteOrder);
  const removeBag = useServerFn(deleteBatch);
  const runSearch = useServerFn(searchOrders);
  const sheetLink = useServerFn(getSheetLink);

  const selected = todayISO();
  const [summary, setSummary] = useState<{ total: number; bags: Bag[] } | null>(null);
  const [openBag, setOpenBag] = useState<string | null>(null);
  const [bagOrders, setBagOrders] = useState<OrderRow[]>([]);
  const [busy, setBusy] = useState(false);
  const [sheetUrl, setSheetUrl] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [hits, setHits] = useState<Hit[] | null>(null);
  const [confirm, setConfirm] = useState<Confirm>(null);

  const loadDay = useCallback(
    async (day: string, t: string) => {
      const res = await daySummary({ data: { token: t, day } });
      setSummary({ total: res.total, bags: res.bags });
    },
    [daySummary],
  );

  const reloadAll = useCallback(
    async (t: string) => {
      await loadDay(selected, t);
      if (query.trim())
        setHits(
          (await runSearch({ data: { token: t, query } })).filter(
            (h) => h.scanned_at.slice(0, 10) === todayISO(),
          ),
        );
    },
    [loadDay, runSearch, selected, query],
  );

  useEffect(() => {
    if (!ready) return;
    if (!token) {
      void navigate({ to: "/" });
      return;
    }
    void sheetLink({ data: { token } })
      .then((r) => setSheetUrl(r.url))
      .catch(() => undefined);
  }, [ready, token, sheetLink, navigate]);

  useEffect(() => {
    if (token) void loadDay(selected, token);
  }, [token, selected, loadDay]);

  // Live search on order number, debounced so the PDA keyboard stays responsive.
  useEffect(() => {
    if (!token) return;
    const q = query.trim();
    if (!q) {
      setHits(null);
      return;
    }
    const id = window.setTimeout(() => {
      void runSearch({ data: { token, query: q } })
        .then((r) => setHits(r.filter((h) => h.scanned_at.slice(0, 10) === todayISO())))
        .catch(() => setHits([]));
    }, 250);
    return () => window.clearTimeout(id);
  }, [query, token, runSearch]);

  async function toggleBag(bag: Bag) {
    if (!token) return;
    if (openBag === bag.id) {
      setOpenBag(null);
      return;
    }
    const rows = await listOrders({ data: { token, batchId: bag.id } });
    setBagOrders(rows);
    setOpenBag(bag.id);
  }

  async function runConfirmed() {
    if (!token || !confirm || busy || !online) return;
    setBusy(true);
    const target = confirm;
    try {
      if (target.kind === "order") {
        await removeOrder({ data: { token, orderId: target.id } });
        setBagOrders((prev) => prev.filter((o) => o.id !== target.id));
      } else {
        await removeBag({ data: { token, batchId: target.id } });
        if (openBag === target.id) setOpenBag(null);
      }
      setConfirm(null);
      await reloadAll(token);
    } finally {
      setBusy(false);
    }
  }

  if (!ready || !token) return <div className="min-h-screen bg-background" />;

  return (
    <main className="mx-auto flex min-h-screen w-full max-w-2xl flex-col gap-5 px-4 py-6">
      <header className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
        <div className="min-w-0">
          <p className="label-caps">Records</p>
          <h1 className="display truncate text-4xl font-bold">Daily log</h1>
        </div>
        <button
          onClick={() => navigate({ to: "/" })}
          className="pill label-caps shrink-0 border border-border px-4 py-2"
        >
          Home
        </button>
      </header>

      <section className="soft-card p-4">
        <label className="label-caps block" htmlFor="search">
          Search order
        </label>
        <input
          id="search"
          value={query}
          inputMode="numeric"
          placeholder="Type an order number"
          onChange={(e) => setQuery(e.target.value.replace(/\D/g, "").slice(0, 6))}
          className="mt-2 h-14 w-full rounded-2xl border border-border bg-background px-4 font-mono text-xl text-foreground outline-none focus:border-ring"
        />
        {hits ? (
          <ul className="mt-3 divide-y divide-border overflow-hidden rounded-2xl border border-border">
            {hits.length === 0 ? (
              <li className="px-4 py-3 text-muted-foreground">No order matches “{query}”.</li>
            ) : (
              hits.map((h) => (
                <li
                  key={h.id}
                  className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-4 py-3"
                >
                  <span className="min-w-0">
                    <span className="block font-mono text-xl">{h.order_number}</span>
                    <span className="label-caps">
                      {h.bag_code} · {h.bag_status === "open" ? "Open" : "Sealed"} ·{" "}
                      {h.scanned_at.slice(0, 10)}
                    </span>
                  </span>
                  <button
                    onClick={() =>
                      setConfirm({
                        kind: "order",
                        id: h.id,
                        label: h.order_number,
                        bagLabel: h.bag_code,
                      })
                    }
                    disabled={!online}
                    className="pill bg-destructive px-4 py-3 text-sm text-destructive-foreground disabled:opacity-40"
                  >
                    Delete
                  </button>
                </li>
              ))
            )}
          </ul>
        ) : null}
      </section>

      <section className="soft-card p-5">
        <p className="label-caps">Today · {selected}</p>
        <p className="display mt-4 text-7xl font-bold leading-none tabular-nums text-primary">
          {summary?.total ?? 0}
        </p>
        <p className="label-caps mt-1">Orders scanned that day</p>
      </section>

      <section className="space-y-3">
        <p className="label-caps">Bags ({summary?.bags.length ?? 0})</p>
        {summary && summary.bags.length > 0 ? (
          summary.bags.map((bag) => (
            <div key={bag.id} className="soft-card overflow-hidden">
              <div className="grid grid-cols-[minmax(0,1fr)_auto_auto] items-center gap-3 px-4 py-4">
                <button onClick={() => toggleBag(bag)} className="min-w-0 text-left">
                  <span className="display block truncate font-mono text-xl font-bold text-primary">
                    {bag.code}
                  </span>
                  <span className="label-caps">{bag.status === "open" ? "Open" : "Sealed"}</span>
                </button>
                <span className="display text-3xl font-bold tabular-nums">{bag.count}</span>
                <button
                  onClick={() =>
                    setConfirm({ kind: "bag", id: bag.id, label: bag.code, count: bag.count })
                  }
                  disabled={!online}
                  className="pill border border-destructive px-3 py-2 text-sm text-destructive disabled:opacity-40"
                >
                  Delete bag
                </button>
              </div>
              {openBag === bag.id ? (
                <ul className="divide-y divide-border border-t border-border">
                  {bagOrders.length === 0 ? (
                    <li className="px-4 py-3 text-muted-foreground">No orders in this bag.</li>
                  ) : (
                    bagOrders.map((o) => (
                      <li
                        key={o.id}
                        className="grid grid-cols-[1fr_auto] items-center gap-3 px-4 py-3"
                      >
                        <span className="font-mono text-xl">{o.order_number}</span>
                        <button
                          onClick={() =>
                            setConfirm({
                              kind: "order",
                              id: o.id,
                              label: o.order_number,
                              bagLabel: bag.code,
                            })
                          }
                          disabled={busy || !online}
                          className="pill bg-destructive px-4 py-3 text-sm text-destructive-foreground disabled:opacity-40"
                        >
                          Delete
                        </button>
                      </li>
                    ))
                  )}
                </ul>
              ) : null}
            </div>
          ))
        ) : (
          <p className="rounded-2xl border border-dashed border-border p-6 text-center text-muted-foreground">
            No bags on this day.
          </p>
        )}
      </section>

      {sheetUrl ? (
        <a
          href={sheetUrl}
          target="_blank"
          rel="noreferrer"
          className="pill label-caps border border-border py-4 text-center"
        >
          Open Google Sheet log
        </a>
      ) : null}

      {confirm ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/90 px-5">
          <div className="soft-card w-full max-w-md p-6 text-center">
            <p className="label-caps">
              {confirm.kind === "bag" ? "Delete this bag" : "Delete this order"}
            </p>
            <p className="display mt-1 font-mono text-3xl font-bold text-primary">
              {confirm.label}
            </p>
            <p className="mt-4 text-muted-foreground">
              {confirm.kind === "bag"
                ? `This permanently removes the bag and all ${confirm.count} order${confirm.count === 1 ? "" : "s"} inside it, in the app and in the Google Sheet. This cannot be undone.`
                : `This permanently removes the order${confirm.bagLabel ? ` from bag ${confirm.bagLabel}` : ""}, in the app and in the Google Sheet. This cannot be undone.`}
            </p>
            <div className="mt-6 grid gap-3">
              <button
                autoFocus
                onClick={() => setConfirm(null)}
                className="pad-button pad-button-secondary w-full"
              >
                Cancel
              </button>
              <button
                onClick={runConfirmed}
                disabled={busy || !online}
                className="pad-button pad-button-danger w-full disabled:opacity-40"
              >
                {busy ? "Deleting…" : confirm.kind === "bag" ? "Delete bag" : "Delete order"}
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </main>
  );
}
