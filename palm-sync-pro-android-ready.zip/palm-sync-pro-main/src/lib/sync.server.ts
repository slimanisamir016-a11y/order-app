// Server-only two-way reconciliation between the database and the Google Sheet log.
import { readSheet, withSheetLock, writeSheet } from "./sheets.server";
import { SheetsRequestError } from "./sheets-retry.server";

type OrderRow = {
  id: string;
  order_number: string;
  batch_id: string;
  scanned_at: string;
  batches: { code: string; status: string } | null;
};

/** Orders scanned within this window are never removed by a sheet reconcile. */
const DELETE_GRACE_MS = 10 * 60_000;

async function admin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

export async function getSpreadsheetId(): Promise<string | null> {
  const db = await admin();
  const { data } = await db.from("app_settings").select("spreadsheet_id").eq("id", 1).maybeSingle();
  return data?.spreadsheet_id ?? null;
}

async function allOrders(): Promise<OrderRow[]> {
  const db = await admin();
  const { data, error } = await db
    .from("orders")
    .select("id, order_number, batch_id, scanned_at, batches(code, status)")
    .order("scanned_at", { ascending: true });
  if (error) throw new Error(error.message);
  return (data ?? []) as unknown as OrderRow[];
}

function toRows(orders: OrderRow[]): string[][] {
  return orders.map((o) => [
    o.order_number,
    o.batches?.code ?? "",
    o.batches?.status ?? "",
    o.scanned_at,
    o.scanned_at.slice(0, 10),
  ]);
}

/** Group rows by day: a title row per day and a blank spacer between days. */
function grouped(rows: string[][]): string[][] {
  const out: string[][] = [];
  let day = "";
  for (const row of rows) {
    if (row[4] !== day) {
      if (out.length) out.push(["", "", "", "", ""]);
      day = row[4] ?? "";
      out.push([`DAY ${day}`, "", "", "", ""]);
    }
    out.push(row);
  }
  return out;
}

let pendingPush = false;
let pushing: Promise<void> | undefined;
let lastPushAt = 0;
let syncing: Promise<SyncResult> | undefined;
let cachedSync: SyncResult | undefined;
let lastSyncAt = 0;

/** Coalesce scan bursts; the next automatic sync flushes any deferred changes. */
export async function pushToSheet(): Promise<void> {
  pendingPush = true;
  if (pushing) return pushing;
  if (Date.now() - lastPushAt < 5_000) return;
  const spreadsheetId = await getSpreadsheetId();
  if (!spreadsheetId) return;
  if (pushing) return pushing;
  pushing = withSheetLock(async () => {
    // Read the orders inside the lock so the sheet always reflects the newest state.
    pendingPush = false;
    try {
      await writeSheet(spreadsheetId, grouped(toRows(await allOrders())));
      lastPushAt = Date.now();
    } catch (error) {
      pendingPush = true;
      throw error;
    }
  }).finally(() => { pushing = undefined; });
  return pushing;
}

/** Fire-and-forget push so scanning never waits on Google. */
export function pushToSheetSafe(): void {
  void pushToSheet().catch((e) => console.error("[sheets] push failed", e));
}

export type SyncResult = {
  ok: boolean;
  added: number;
  removed: number;
  skipped: string[];
  message?: string;
  retryAt?: number;
  status?: number;
  errorBody?: string;
};

/**
 * Pull the sheet, apply rows added/removed there to the database,
 * then push the reconciled state back so both sides match exactly.
 *
 * Deletions are deliberately conservative: a stale or partially written sheet
 * must never wipe scanned orders out of the database.
 */
export async function syncWithSheet(): Promise<SyncResult> {
  if (syncing) return syncing;
  if (!pendingPush && cachedSync && Date.now() - lastSyncAt < 60_000) return cachedSync;
  syncing = reconcileSheet().then((result) => {
    if (result.ok) {
      cachedSync = { ...result, added: 0, removed: 0 };
      lastSyncAt = Date.now();
    }
    return result;
  }).catch((error: unknown): SyncResult => {
    if (!(error instanceof SheetsRequestError)) throw error;
    return {
      ok: false, added: 0, removed: 0, skipped: [],
      status: error.status, errorBody: error.body, retryAt: error.retryAt,
      message: error.status === 429
        ? "Google Sheets is busy. Sync will retry automatically; your orders remain saved in the app."
        : "Google Sheets is unavailable. Your orders remain saved in the app.",
    };
  }).finally(() => { syncing = undefined; });
  return syncing;
}

async function reconcileSheet(): Promise<SyncResult> {
  const spreadsheetId = await getSpreadsheetId();
  if (!spreadsheetId)
    return { ok: false, added: 0, removed: 0, skipped: [], message: "No sheet linked" };

  return withSheetLock(async () => {
    const db = await admin();
    // Never interpret an old sheet as deletions when an app write is still pending.
    if (pendingPush) {
      pendingPush = false;
      try {
        await writeSheet(spreadsheetId, grouped(toRows(await allOrders())));
        lastPushAt = Date.now();
      } catch (error) {
        pendingPush = true;
        throw error;
      }
    }
    const sheetRows = await readSheet(spreadsheetId);
    const orders = await allOrders();

    const dbByNumber = new Map(orders.map((o) => [o.order_number, o]));
    const sheetNumbers = new Set(sheetRows.map((r) => r.orderNumber));

    let added = 0;
    let removed = 0;
    const skipped: string[] = [];

    // Rows added directly in the sheet -> insert into the matching bag.
    const { data: batches } = await db.from("batches").select("id, code, status").order("created_at", { ascending: true });
    const byCode = new Map((batches ?? []).map((b) => [b.code, b]));
    const openBatch = (batches ?? []).find((b) => b.status === "open");

    for (const row of sheetRows) {
      if (dbByNumber.has(row.orderNumber)) continue;
      const target = byCode.get(row.bagCode) ?? openBatch;
      if (!target) {
        skipped.push(row.orderNumber);
        continue;
      }
      const { data: res, error } = await db.rpc("add_scan_to_batch", {
        p_batch_id: target.id,
        p_order_number: row.orderNumber,
        p_source: "sheet",
      });
      if (error) {
        skipped.push(row.orderNumber);
        continue;
      }
      if ((res as { result: string }).result === "accepted") added += 1;
    }

    // Rows removed from the sheet -> delete from the database.
    // Guards against data loss from a stale/partial sheet read:
    //  - an empty sheet is "not yet populated", never "delete everything";
    //  - a sheet missing a large share of the orders is treated as unreliable;
    //  - just-scanned orders are protected by a grace window.
    const now = Date.now();
    const candidates = orders.filter(
      (o) =>
        !sheetNumbers.has(o.order_number) &&
        now - new Date(o.scanned_at).getTime() > DELETE_GRACE_MS,
    );
    const reliable =
      sheetRows.length > 0 && (orders.length === 0 || sheetRows.length >= orders.length * 0.8);

    if (reliable) {
      for (const o of candidates) {
        const { error } = await db.rpc("delete_order", {
          p_order_id: o.id,
          p_reason: "removed in Google Sheet",
        });
        if (!error) removed += 1;
      }
    } else if (candidates.length > 0) {
      console.warn("[sheets] skipped deletions — sheet looked incomplete", {
        sheetRows: sheetRows.length,
        dbOrders: orders.length,
      });
    }

    const rows = toRows(await allOrders());
    // Do not rewrite a matching sheet on every poll.
    if (added || removed || sheetRows.length !== rows.length ||
      rows.some((row, i) => row[0] !== sheetRows[i]?.orderNumber || row[1] !== sheetRows[i]?.bagCode)) {
      await writeSheet(spreadsheetId, grouped(rows));
    }
    await db.from("app_settings").update({ sheet_synced_at: new Date().toISOString() }).eq("id", 1);

    return { ok: true, added, removed, skipped };
  });
}
