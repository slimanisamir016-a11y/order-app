// Server-only Google Sheets access through the Lovable connector gateway.
import { retryDelay, SheetsRequestError } from "./sheets-retry.server";

const GATEWAY = "https://connector-gateway.lovable.dev/google_sheets/v4/spreadsheets";
const TAB = "Orders";

export const HEADER = ["Order number", "Bag", "Bag status", "Scanned at (UTC)", "Day"];

/**
 * Every sheet operation runs through this queue. Reads and writes must never
 * interleave: a read that lands in the middle of a rewrite sees a truncated
 * sheet, and the reconciler would then treat live orders as "deleted".
 */
let chain: Promise<unknown> = Promise.resolve();
export function withSheetLock<T>(fn: () => Promise<T>): Promise<T> {
  const run = chain.then(fn, fn);
  chain = run.catch(() => undefined);
  return run;
}

function headers() {
  const lovableKey = process.env["LOVABLE_API_KEY"];
  const connKey = process.env["GOOGLE_SHEETS_API_KEY"];
  if (!lovableKey || !connKey) throw new Error("Google Sheets is not connected");
  return {
    Authorization: `Bearer ${lovableKey}`,
    "X-Connection-Api-Key": connKey,
    "Content-Type": "application/json",
  };
}

let retryAt = 0;
let failures = 0;
let lastFailure: SheetsRequestError | undefined;

async function call(path: string, init?: RequestInit) {
  if (Date.now() < retryAt && lastFailure) throw lastFailure;
  const res = await fetch(`${GATEWAY}${path}`, { ...init, headers: headers() });
  if (!res.ok) {
    const body = await res.text();
    if (res.status === 429 || res.status >= 500) {
      failures += 1;
      retryAt = Date.now() + retryDelay(res.headers.get("Retry-After"), failures, Date.now());
    }
    lastFailure = new SheetsRequestError(res.status, body, retryAt);
    console.error(`Google Sheets request failed [${res.status}]: ${body}`);
    throw lastFailure;
  }
  failures = 0;
  retryAt = 0;
  return res.json() as Promise<Record<string, unknown>>;
}

export type SheetRow = {
  orderNumber: string;
  bagCode: string;
};

export async function readSheet(spreadsheetId: string): Promise<SheetRow[]> {
  const data = await call(`/${spreadsheetId}/values/${TAB}!A2:E?majorDimension=ROWS`);
  const values = (data["values"] as string[][] | undefined) ?? [];
  return values
    .map((row) => ({
      orderNumber: String(row[0] ?? "").trim(),
      bagCode: String(row[1] ?? "").trim(),
    }))
    .filter((r) => /^\d{6}$/.test(r.orderNumber));
}

export async function writeSheet(spreadsheetId: string, rows: string[][]): Promise<void> {
  const values = [HEADER, ...rows];
  // Write first, clear the leftover tail afterwards, so the sheet is never empty
  // mid-operation (an empty read used to look like "all orders were deleted").
  await call(`/${spreadsheetId}/values/${TAB}!A1:E${values.length}?valueInputOption=RAW`, {
    method: "PUT",
    body: JSON.stringify({
      range: `${TAB}!A1:E${values.length}`,
      majorDimension: "ROWS",
      values,
    }),
  });
  await call(`/${spreadsheetId}/values/${TAB}!A${values.length + 1}:E100000:clear`, {
    method: "POST",
    body: "{}",
  });
}
