// Server-only helpers for the Order Traceability Tool.
// Shared-access-code session tokens are signed with HMAC-SHA256.

const encoder = new TextEncoder();

function b64url(bytes: Uint8Array): string {
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

async function hmac(payload: string): Promise<string> {
  const secret = process.env["OTT_SESSION_SECRET"];
  if (!secret) throw new Error("OTT_SESSION_SECRET is not configured");
  const key = await crypto.subtle.importKey(
    "raw",
    encoder.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const sig = await crypto.subtle.sign("HMAC", key, encoder.encode(payload));
  return b64url(new Uint8Array(sig));
}

export async function sha256Hex(value: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", encoder.encode(value));
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

const SESSION_DAYS = 30;

export async function issueSession(): Promise<string> {
  const payload = String(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  return `${payload}.${await hmac(payload)}`;
}

export async function assertSession(token: string | undefined): Promise<void> {
  const parts = (token ?? "").split(".");
  const payload = parts[0];
  const sig = parts[1];
  if (!payload || !sig) throw new Error("LOCKED");
  const expected = await hmac(payload);
  if (sig.length !== expected.length) throw new Error("LOCKED");
  let diff = 0;
  for (let i = 0; i < sig.length; i++) diff |= sig.charCodeAt(i) ^ expected.charCodeAt(i);
  if (diff !== 0) throw new Error("LOCKED");
  if (Number(payload) < Date.now()) throw new Error("LOCKED");
}
