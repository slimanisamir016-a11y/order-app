import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const tokenSchema = z.object({ token: z.string().min(1) });
const batchSchema = tokenSchema.extend({ batchId: z.string().uuid() });

export const unlockDevice = createServerFn({ method: "POST" })
  .inputValidator((input) => z.object({ code: z.string().min(1).max(64) }).parse(input))
  .handler(async ({ data }) => {
    const { sha256Hex, issueSession } = await import("./ott.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row, error } = await supabaseAdmin
      .from("app_access")
      .select("code_hash")
      .eq("id", 1)
      .maybeSingle();
    if (error) throw new Error(error.message);
    const hash = await sha256Hex(data.code.trim());
    if (!row || row.code_hash !== hash) return { ok: false as const };
    return { ok: true as const, token: await issueSession() };
  });

export const getOpenBatch = createServerFn({ method: "POST" })
  .inputValidator((input) => tokenSchema.parse(input))
  .handler(async ({ data }) => {
    const { assertSession } = await import("./ott.server");
    await assertSession(data.token);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: batch, error } = await supabaseAdmin
      .from("batches")
      .select("id, code, created_at")
      .eq("status", "open")
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!batch) return { batch: null };
    const { count } = await supabaseAdmin
      .from("orders")
      .select("id", { count: "exact", head: true })
      .eq("batch_id", batch.id);
    return { batch: { ...batch, count: count ?? 0 } };
  });

export const startBatch = createServerFn({ method: "POST" })
  .inputValidator((input) => tokenSchema.parse(input))
  .handler(async ({ data }) => {
    const { assertSession } = await import("./ott.server");
    await assertSession(data.token);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: batch, error } = await supabaseAdmin.rpc("start_batch");
    if (error) throw new Error(error.message);
    return { batch: batch as { id: string; code: string; created_at: string } };
  });

export const scanOrder = createServerFn({ method: "POST" })
  .inputValidator((input) =>
    batchSchema.extend({ orderNumber: z.string().trim().min(1).max(128) }).parse(input),
  )
  .handler(async ({ data }) => {
    const { assertSession } = await import("./ott.server");
    await assertSession(data.token);
    // Order numbers are exactly six digits — anything else is rejected outright.
    if (!/^\d{6}$/.test(data.orderNumber)) {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      const { count } = await supabaseAdmin
        .from("orders")
        .select("id", { count: "exact", head: true })
        .eq("batch_id", data.batchId);
      return { result: "bad_format" as const, count: count ?? 0 };
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: result, error } = await supabaseAdmin.rpc("add_scan", {
      p_batch_id: data.batchId,
      p_order_number: data.orderNumber,
    });
    if (error) throw new Error(error.message);
    const parsed = result as { result: "accepted" | "duplicate"; count: number; same_batch?: boolean };
    if (parsed.result === "accepted") {
      const { pushToSheetSafe } = await import("./sync.server");
      pushToSheetSafe();
    }
    return parsed as {
      result: "accepted" | "duplicate" | "bad_format";
      count: number;
      same_batch?: boolean;
    };
  });


export const undoLastScan = createServerFn({ method: "POST" })
  .inputValidator((input) => batchSchema.parse(input))
  .handler(async ({ data }) => {
    const { assertSession } = await import("./ott.server");
    await assertSession(data.token);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: result, error } = await supabaseAdmin.rpc("undo_last_scan", {
      p_batch_id: data.batchId,
    });
    if (error) throw new Error(error.message);
    const { pushToSheetSafe } = await import("./sync.server");
    pushToSheetSafe();
    return result as { result: "undone" | "empty"; order_number?: string; count: number };
  });

export const validateBatch = createServerFn({ method: "POST" })
  .inputValidator((input) => batchSchema.parse(input))
  .handler(async ({ data }) => {
    const { assertSession } = await import("./ott.server");
    await assertSession(data.token);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: result, error } = await supabaseAdmin.rpc("validate_batch", {
      p_batch_id: data.batchId,
    });
    if (error) throw new Error(error.message);
    const { pushToSheetSafe } = await import("./sync.server");
    pushToSheetSafe();
    return result as { result: "validated"; validated_at: string; count: number };
  });

export const deleteOrder = createServerFn({ method: "POST" })
  .inputValidator((input) => tokenSchema.extend({ orderId: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const { assertSession } = await import("./ott.server");
    await assertSession(data.token);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: result, error } = await supabaseAdmin.rpc("delete_order", {
      p_order_id: data.orderId,
      p_reason: "deleted in app",
    });
    if (error) throw new Error(error.message);
    const { pushToSheetSafe } = await import("./sync.server");
    pushToSheetSafe();
    return result as {
      result: "deleted" | "missing";
      order_number?: string;
      batch_id?: string;
      count?: number;
    };
  });

export const getBatchOrders = createServerFn({ method: "POST" })
  .inputValidator((input) => batchSchema.parse(input))
  .handler(async ({ data }) => {
    const { assertSession } = await import("./ott.server");
    await assertSession(data.token);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: result, error } = await supabaseAdmin.rpc("batch_orders", {
      p_batch_id: data.batchId,
    });
    if (error) throw new Error(error.message);
    return result as { id: string; order_number: string; scanned_at: string }[];
  });

export const getDaySummary = createServerFn({ method: "POST" })
  .inputValidator((input) =>
    tokenSchema.extend({ day: z.string().regex(/^\d{4}-\d{2}-\d{2}$/) }).parse(input),
  )
  .handler(async ({ data }) => {
    const { assertSession } = await import("./ott.server");
    await assertSession(data.token);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: result, error } = await supabaseAdmin.rpc("day_summary", { p_day: data.day });
    if (error) throw new Error(error.message);
    return result as {
      day: string;
      total: number;
      bags: {
        id: string;
        code: string;
        status: "open" | "validated";
        created_at: string;
        validated_at: string | null;
        count: number;
      }[];
    };
  });

export const getRecentDays = createServerFn({ method: "POST" })
  .inputValidator((input) => tokenSchema.parse(input))
  .handler(async ({ data }) => {
    const { assertSession } = await import("./ott.server");
    await assertSession(data.token);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: result, error } = await supabaseAdmin.rpc("recent_days", { p_limit: 60 });
    if (error) throw new Error(error.message);
    return result as { day: string; total: number; bags: number }[];
  });

export const syncSheet = createServerFn({ method: "POST" })
  .inputValidator((input) => tokenSchema.parse(input))
  .handler(async ({ data }) => {
    const { assertSession } = await import("./ott.server");
    await assertSession(data.token);
    const { syncWithSheet } = await import("./sync.server");
    return await syncWithSheet();
  });

export const getSheetLink = createServerFn({ method: "POST" })
  .inputValidator((input) => tokenSchema.parse(input))
  .handler(async ({ data }) => {
    const { assertSession } = await import("./ott.server");
    await assertSession(data.token);
    const { getSpreadsheetId } = await import("./sync.server");
    const id = await getSpreadsheetId();
    return { url: id ? `https://docs.google.com/spreadsheets/d/${id}/edit` : null };
  });


export const deleteBatch = createServerFn({ method: "POST" })
  .inputValidator((input) => batchSchema.parse(input))
  .handler(async ({ data }) => {
    const { assertSession } = await import("./ott.server");
    await assertSession(data.token);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: result, error } = await supabaseAdmin.rpc("delete_batch", {
      p_batch_id: data.batchId,
      p_reason: "deleted in app",
    });
    if (error) throw new Error(error.message);
    const { pushToSheetSafe } = await import("./sync.server");
    pushToSheetSafe();
    return result as { result: "deleted" | "missing"; code?: string; order_count?: number };
  });

export const searchOrders = createServerFn({ method: "POST" })
  .inputValidator((input) => tokenSchema.extend({ query: z.string().trim().max(32) }).parse(input))
  .handler(async ({ data }) => {
    const { assertSession } = await import("./ott.server");
    await assertSession(data.token);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const q = data.query.replace(/\D/g, "");
    if (!q) return [];
    const { data: rows, error } = await supabaseAdmin
      .from("orders")
      .select("id, order_number, scanned_at, batches(code, status)")
      .like("order_number", `%${q}%`)
      .order("scanned_at", { ascending: false })
      .limit(50);
    if (error) throw new Error(error.message);
    return (rows ?? []).map((r) => {
      const row = r as unknown as {
        id: string;
        order_number: string;
        scanned_at: string;
        batches: { code: string; status: string } | null;
      };
      return {
        id: row.id,
        order_number: row.order_number,
        scanned_at: row.scanned_at,
        bag_code: row.batches?.code ?? "",
        bag_status: row.batches?.status ?? "",
      };
    });
  });

// A bag with zero scanned orders is never kept: it is discarded instead of
// lingering as an empty bag in the log, on Home, and in the Google Sheet.
export const discardEmptyBatch = createServerFn({ method: "POST" })
  .inputValidator((input) => batchSchema.parse(input))
  .handler(async ({ data }) => {
    const { assertSession } = await import("./ott.server");
    await assertSession(data.token);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { count } = await supabaseAdmin
      .from("orders")
      .select("id", { count: "exact", head: true })
      .eq("batch_id", data.batchId);
    if ((count ?? 0) > 0) return { discarded: false as const };
    const { data: result, error } = await supabaseAdmin.rpc("delete_batch", {
      p_batch_id: data.batchId,
      p_reason: "empty bag discarded",
    });
    if (error) throw new Error(error.message);
    const { pushToSheetSafe } = await import("./sync.server");
    pushToSheetSafe();
    return { discarded: (result as { result?: string })?.result === "deleted" };
  });
