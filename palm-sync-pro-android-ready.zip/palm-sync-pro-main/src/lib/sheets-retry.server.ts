/** Provider cooldown shared by requests within this server instance. */
export class SheetsRequestError extends Error {
  constructor(public status: number, public body: string, public retryAt = 0) {
    super(`Google Sheets request failed [${status}]: ${body}`);
  }
}

export function retryDelay(header: string | null, attempts: number, now: number): number {
  const seconds = header === null ? NaN : Number(header);
  const date = header === null ? NaN : Date.parse(header);
  const providerDelay = Number.isFinite(seconds)
    ? seconds * 1000
    : Number.isFinite(date) ? date - now : 0;
  return Math.max(providerDelay, Math.min(60_000 * 2 ** (attempts - 1), 15 * 60_000));
}