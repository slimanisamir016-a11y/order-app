# PDA Sync Buddy

I wanna build an app that match with Both of PDA and Computer but its specially for a PDA, ill give u the description of the app ect...

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://palm-sync-pro.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/b1944b76-4469-4c75-837e-50c7f20ea3e1).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
