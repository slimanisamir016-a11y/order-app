import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.mazyoud.palmsyncpro",
  appName: "PDA Sync Buddy",
  webDir: "dist",
  server: {
    // The TanStack Start app contains server functions, so the Android shell
    // loads the deployed web app rather than trying to run the Node server locally.
    url: process.env.CAPACITOR_SERVER_URL || "https://palm-sync-pro.lovable.app",
    cleartext: false,
  },
  android: {
    allowMixedContent: false,
    backgroundColor: "#0b0f14",
  },
};

export default config;
