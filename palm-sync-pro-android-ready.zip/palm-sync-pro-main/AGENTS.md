<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Sheets retry policy lives in a server-only helper; sync coalesces concurrent requests and caches successful reconciliations to reduce provider quota usage. These in-memory optimizations are instance-local, not distributed locks.
- Pending app writes must be flushed before reading Sheets for deletion reconciliation so a failed or deferred push cannot erase saved orders.
