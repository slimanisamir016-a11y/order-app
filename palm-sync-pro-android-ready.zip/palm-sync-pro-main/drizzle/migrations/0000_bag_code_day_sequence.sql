ALTER TABLE public.batches DROP CONSTRAINT batches_code_key;
ALTER TABLE public.batches ALTER COLUMN code DROP DEFAULT;
CREATE OR REPLACE FUNCTION public.set_batch_code() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
DECLARE n int;
BEGIN
  IF NEW.code IS NULL OR NEW.code = '' THEN
    PERFORM pg_advisory_xact_lock(hashtext('batch_code'));
    SELECT COALESCE(MAX(NULLIF(split_part(code, '/', 2), '')::int), 0) + 1 INTO n
      FROM public.batches
     WHERE (created_at AT TIME ZONE 'UTC')::date = (now() AT TIME ZONE 'UTC')::date
       AND code ~ '^\d{2}/\d+$';
    NEW.code := to_char(now() AT TIME ZONE 'UTC', 'DD') || '/' || lpad(n::text, 2, '0');
  END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS trg_set_batch_code ON public.batches;
CREATE TRIGGER trg_set_batch_code BEFORE INSERT ON public.batches FOR EACH ROW EXECUTE FUNCTION public.set_batch_code();