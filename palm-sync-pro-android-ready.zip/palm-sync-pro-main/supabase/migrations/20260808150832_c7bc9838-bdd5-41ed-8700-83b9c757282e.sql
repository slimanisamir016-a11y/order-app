REVOKE EXECUTE ON FUNCTION public.add_scan(uuid, text) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.add_scan_to_batch(uuid, text, text) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.start_batch() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.undo_last_scan(uuid) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.validate_batch(uuid) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.delete_order(uuid, text) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.day_summary(date) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.batch_orders(uuid) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.recent_days(int) FROM PUBLIC, anon, authenticated;