CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TYPE public.batch_status AS ENUM ('open','validated');

CREATE TABLE public.batches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE DEFAULT to_char(now(),'YYYYMMDD') || '-' || upper(substr(replace(gen_random_uuid()::text,'-',''),1,4)),
  status public.batch_status NOT NULL DEFAULT 'open',
  created_at timestamptz NOT NULL DEFAULT now(),
  validated_at timestamptz
);
GRANT ALL ON public.batches TO service_role;
ALTER TABLE public.batches ENABLE ROW LEVEL SECURITY;

CREATE UNIQUE INDEX one_open_batch ON public.batches ((status)) WHERE status = 'open';

CREATE TABLE public.orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  batch_id uuid NOT NULL REFERENCES public.batches(id) ON DELETE CASCADE,
  order_number text NOT NULL UNIQUE,
  scanned_at timestamptz NOT NULL DEFAULT now(),
  validated_at timestamptz
);
GRANT ALL ON public.orders TO service_role;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
CREATE INDEX orders_batch_idx ON public.orders (batch_id, scanned_at DESC);

CREATE TABLE public.audit_log (
  id bigserial PRIMARY KEY,
  event_type text NOT NULL,
  batch_id uuid,
  order_number text,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  detail jsonb
);
GRANT ALL ON public.audit_log TO service_role;
GRANT USAGE, SELECT ON SEQUENCE public.audit_log_id_seq TO service_role;
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.app_access (
  id int PRIMARY KEY DEFAULT 1,
  code_hash text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT app_access_singleton CHECK (id = 1)
);
GRANT ALL ON public.app_access TO service_role;
ALTER TABLE public.app_access ENABLE ROW LEVEL SECURITY;

INSERT INTO public.app_access (id, code_hash) VALUES (1, encode(digest('7412','sha256'),'hex'));

-- Immutability of validated batches
CREATE OR REPLACE FUNCTION public.guard_validated_batch()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    IF OLD.status = 'validated' THEN RAISE EXCEPTION 'Validated batches are immutable'; END IF;
    RETURN OLD;
  END IF;
  IF OLD.status = 'validated' THEN RAISE EXCEPTION 'Validated batches are immutable'; END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER batches_immutable BEFORE UPDATE OR DELETE ON public.batches
FOR EACH ROW EXECUTE FUNCTION public.guard_validated_batch();

CREATE OR REPLACE FUNCTION public.guard_validated_order()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
DECLARE s public.batch_status;
BEGIN
  SELECT status INTO s FROM public.batches WHERE id = COALESCE(OLD.batch_id, NEW.batch_id);
  IF s = 'validated' AND NOT (TG_OP = 'UPDATE' AND OLD.validated_at IS NULL AND NEW.validated_at IS NOT NULL) THEN
    RAISE EXCEPTION 'Orders in a validated batch are immutable';
  END IF;
  IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER orders_immutable BEFORE INSERT OR UPDATE OR DELETE ON public.orders
FOR EACH ROW EXECUTE FUNCTION public.guard_validated_order();

-- Business operations
CREATE OR REPLACE FUNCTION public.start_batch()
RETURNS public.batches LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE b public.batches;
BEGIN
  SELECT * INTO b FROM public.batches WHERE status = 'open' LIMIT 1;
  IF FOUND THEN RETURN b; END IF;
  INSERT INTO public.batches DEFAULT VALUES RETURNING * INTO b;
  INSERT INTO public.audit_log (event_type, batch_id) VALUES ('batch_started', b.id);
  RETURN b;
END;
$$;

CREATE OR REPLACE FUNCTION public.add_scan(p_batch_id uuid, p_order_number text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE existing public.orders; n int;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.batches WHERE id = p_batch_id AND status = 'open') THEN
    RAISE EXCEPTION 'Batch is not open';
  END IF;
  SELECT * INTO existing FROM public.orders WHERE order_number = p_order_number;
  IF FOUND THEN
    INSERT INTO public.audit_log (event_type, batch_id, order_number, detail)
    VALUES ('scan_duplicate', p_batch_id, p_order_number, jsonb_build_object('existing_batch_id', existing.batch_id));
    SELECT count(*) INTO n FROM public.orders WHERE batch_id = p_batch_id;
    RETURN jsonb_build_object('result','duplicate','count',n,'same_batch', existing.batch_id = p_batch_id);
  END IF;
  INSERT INTO public.orders (batch_id, order_number) VALUES (p_batch_id, p_order_number);
  INSERT INTO public.audit_log (event_type, batch_id, order_number) VALUES ('scan_added', p_batch_id, p_order_number);
  SELECT count(*) INTO n FROM public.orders WHERE batch_id = p_batch_id;
  RETURN jsonb_build_object('result','accepted','count',n);
END;
$$;

CREATE OR REPLACE FUNCTION public.undo_last_scan(p_batch_id uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE last_order public.orders; n int;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.batches WHERE id = p_batch_id AND status = 'open') THEN
    RAISE EXCEPTION 'Batch is not open';
  END IF;
  SELECT * INTO last_order FROM public.orders WHERE batch_id = p_batch_id ORDER BY scanned_at DESC, id DESC LIMIT 1;
  IF NOT FOUND THEN RETURN jsonb_build_object('result','empty','count',0); END IF;
  DELETE FROM public.orders WHERE id = last_order.id;
  INSERT INTO public.audit_log (event_type, batch_id, order_number) VALUES ('scan_undone', p_batch_id, last_order.order_number);
  SELECT count(*) INTO n FROM public.orders WHERE batch_id = p_batch_id;
  RETURN jsonb_build_object('result','undone','order_number', last_order.order_number, 'count', n);
END;
$$;

CREATE OR REPLACE FUNCTION public.validate_batch(p_batch_id uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE ts timestamptz; n int;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.batches WHERE id = p_batch_id AND status = 'open') THEN
    RAISE EXCEPTION 'Batch is not open';
  END IF;
  ts := now();
  UPDATE public.orders SET validated_at = ts WHERE batch_id = p_batch_id;
  GET DIAGNOSTICS n = ROW_COUNT;
  UPDATE public.batches SET status = 'validated', validated_at = ts WHERE id = p_batch_id;
  INSERT INTO public.audit_log (event_type, batch_id, occurred_at, detail)
  VALUES ('batch_validated', p_batch_id, ts, jsonb_build_object('order_count', n));
  RETURN jsonb_build_object('result','validated','validated_at', ts, 'count', n);
END;
$$;

REVOKE ALL ON FUNCTION public.start_batch(), public.add_scan(uuid,text), public.undo_last_scan(uuid), public.validate_batch(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.start_batch(), public.add_scan(uuid,text), public.undo_last_scan(uuid), public.validate_batch(uuid) TO service_role;