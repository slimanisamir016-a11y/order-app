CREATE OR REPLACE FUNCTION public.guard_validated_batch()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO 'public'
AS $function$
BEGIN
  IF current_setting('app.allow_delete', true) = '1' THEN
    IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
    RETURN NEW;
  END IF;
  IF TG_OP = 'DELETE' THEN
    IF OLD.status = 'validated' THEN RAISE EXCEPTION 'Validated batches are immutable'; END IF;
    RETURN OLD;
  END IF;
  IF OLD.status = 'validated' THEN RAISE EXCEPTION 'Validated batches are immutable'; END IF;
  RETURN NEW;
END;
$function$;

CREATE OR REPLACE FUNCTION public.delete_batch(p_batch_id uuid, p_reason text DEFAULT NULL::text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE b public.batches; n int;
BEGIN
  SELECT * INTO b FROM public.batches WHERE id = p_batch_id;
  IF NOT FOUND THEN RETURN jsonb_build_object('result','missing'); END IF;
  SELECT count(*) INTO n FROM public.orders WHERE batch_id = p_batch_id;
  PERFORM set_config('app.allow_delete', '1', true);
  DELETE FROM public.orders WHERE batch_id = p_batch_id;
  DELETE FROM public.batches WHERE id = p_batch_id;
  PERFORM set_config('app.allow_delete', '0', true);
  INSERT INTO public.audit_log (event_type, batch_id, detail)
  VALUES ('batch_deleted', p_batch_id, jsonb_build_object('code', b.code, 'order_count', n, 'reason', p_reason));
  RETURN jsonb_build_object('result','deleted','code', b.code, 'order_count', n);
END;
$function$;

CREATE OR REPLACE FUNCTION public.day_summary(p_day date)
 RETURNS jsonb
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT jsonb_build_object(
    'day', p_day,
    'total', (SELECT count(*) FROM public.orders o WHERE (o.scanned_at AT TIME ZONE 'UTC')::date = p_day),
    'bags', COALESCE((
      SELECT jsonb_agg(x ORDER BY x->>'created_at' DESC)
      FROM (
        SELECT jsonb_build_object(
          'id', b.id, 'code', b.code, 'status', b.status,
          'created_at', b.created_at, 'validated_at', b.validated_at,
          'count', (SELECT count(*) FROM public.orders o WHERE o.batch_id = b.id
                    AND (o.scanned_at AT TIME ZONE 'UTC')::date = p_day)
        ) AS x
        FROM public.batches b
        WHERE (b.created_at AT TIME ZONE 'UTC')::date = p_day
           OR EXISTS (SELECT 1 FROM public.orders o WHERE o.batch_id = b.id
                      AND (o.scanned_at AT TIME ZONE 'UTC')::date = p_day)
      ) t
    ), '[]'::jsonb)
  );
$function$;