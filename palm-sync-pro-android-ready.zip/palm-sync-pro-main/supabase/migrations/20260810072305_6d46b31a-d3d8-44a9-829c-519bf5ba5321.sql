INSERT INTO public.batches (id, code, status, created_at, validated_at)
VALUES ('dabc3075-9f81-4033-acd9-358d89c66161','20260809-A8D3','open','2026-08-09 09:06:59.425862+00', NULL);

INSERT INTO public.orders (batch_id, order_number, scanned_at, validated_at) VALUES
 ('dabc3075-9f81-4033-acd9-358d89c66161','333333','2026-08-09 09:07:05.844106+00','2026-08-09 09:07:12.918836+00'),
 ('dabc3075-9f81-4033-acd9-358d89c66161','555555','2026-08-09 09:07:09.61595+00','2026-08-09 09:07:12.918836+00');

UPDATE public.batches SET status='validated', validated_at='2026-08-09 09:07:12.918836+00'
WHERE id='dabc3075-9f81-4033-acd9-358d89c66161';

INSERT INTO public.audit_log (event_type, batch_id, detail)
VALUES ('batch_restored','dabc3075-9f81-4033-acd9-358d89c66161', jsonb_build_object('code','20260809-A8D3','order_count',2,'reason','restored after delete-button test'));