-- 1. Clean legacy test rows that don't match the 6-digit format
ALTER TABLE public.orders DISABLE TRIGGER orders_immutable;
DELETE FROM public.orders WHERE order_number !~ '^[0-9]{6}$';
ALTER TABLE public.orders ENABLE TRIGGER orders_immutable;

-- 2. Enforce 6-digit order numbers
ALTER TABLE public.orders ADD CONSTRAINT orders_six_digits CHECK (order_number ~ '^[0-9]{6}$');

-- 3. Allow deletion of any order (even in a sealed bag) when explicitly authorised
CREATE OR REPLACE FUNCTION public.guard_validated_order()
RETURNS trigger
LANGUAGE plpgsql
SET search_path TO 'public'
AS $function$
DECLARE s public.batch_status;
BEGIN
  IF TG_OP = 'DELETE' AND current_setting('app.allow_delete', true) = '1' THEN
    RETURN OLD;
  END IF;
  SELECT status INTO s FROM public.batches WHERE id = COALESCE(OLD.batch_id, NEW.batch_id);
  IF s = 'validated' AND NOT (TG_OP = 'UPDATE' AND OLD.validated_at IS NULL AND NEW.validated_at IS NOT NULL) THEN
    RAISE EXCEPTION 'Orders in a validated batch are immutable';
  END IF;
  IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
  RETURN NEW;
END;
$function$;

CREATE OR REPLACE FUNCTION public.delete_order(p_order_id uuid, p_reason text DEFAULT NULL)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE o public.orders; n int;
BEGIN
  SELECT * INTO o FROM public.orders WHERE id = p_order_id;
  IF NOT FOUND THEN RETURN jsonb_build_object('result','missing'); END IF;
  PERFORM set_config('app.allow_delete', '1', true);
  DELETE FROM public.orders WHERE id = p_order_id;
  PERFORM set_config('app.allow_delete', '0', true);
  INSERT INTO public.audit_log (event_type, batch_id, order_number, detail)
  VALUES ('order_deleted', o.batch_id, o.order_number, jsonb_build_object('reason', p_reason));
  SELECT count(*) INTO n FROM public.orders WHERE batch_id = o.batch_id;
  RETURN jsonb_build_object('result','deleted','order_number',o.order_number,'batch_id',o.batch_id,'count',n);
END;
$function$;

-- 4. Daily totals
CREATE OR REPLACE FUNCTION public.day_summary(p_day date)
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
  SELECT jsonb_build_object(
    'day', p_day,
    'total', (SELECT count(*) FROM public.orders o WHERE (o.scanned_at AT TIME ZONE 'UTC')::date = p_day),
    'bags', COALESCE((
      SELECT jsonb_agg(x ORDER BY x->>'created_at' DESC)
      FROM (
        SELECT jsonb_build_object(
          'id', b.id, 'code', b.code, 'status', b.status,
          'created_at', b.created_at, 'validated_at', b.validated_at,
          'count', (SELECT count(*) FROM public.orders o WHERE o.batch_id = b.id)
        ) AS x
        FROM public.batches b
        WHERE (b.created_at AT TIME ZONE 'UTC')::date = p_day
      ) t
    ), '[]'::jsonb)
  );
$function$;

CREATE OR REPLACE FUNCTION public.batch_orders(p_batch_id uuid)
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
  SELECT COALESCE(jsonb_agg(jsonb_build_object('id', o.id, 'order_number', o.order_number, 'scanned_at', o.scanned_at) ORDER BY o.scanned_at DESC), '[]'::jsonb)
  FROM public.orders o WHERE o.batch_id = p_batch_id;
$function$;

CREATE OR REPLACE FUNCTION public.recent_days(p_limit int DEFAULT 30)
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
  SELECT COALESCE(jsonb_agg(d ORDER BY d->>'day' DESC), '[]'::jsonb) FROM (
    SELECT jsonb_build_object(
      'day', (o.scanned_at AT TIME ZONE 'UTC')::date,
      'total', count(*),
      'bags', count(DISTINCT o.batch_id)
    ) AS d
    FROM public.orders o
    GROUP BY (o.scanned_at AT TIME ZONE 'UTC')::date
    ORDER BY 1 DESC
    LIMIT p_limit
  ) t;
$function$;

-- 5. Settings for the linked Google Sheet
CREATE TABLE public.app_settings (
  id integer PRIMARY KEY DEFAULT 1,
  spreadsheet_id text,
  sheet_synced_at timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT app_settings_singleton CHECK (id = 1)
);
GRANT ALL ON public.app_settings TO service_role;
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;
INSERT INTO public.app_settings (id) VALUES (1);

-- 6. Insert an order into a specific batch (used by Google Sheet -> app sync)
CREATE OR REPLACE FUNCTION public.add_scan_to_batch(p_batch_id uuid, p_order_number text, p_source text DEFAULT 'sheet')
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  IF EXISTS (SELECT 1 FROM public.orders WHERE order_number = p_order_number) THEN
    RETURN jsonb_build_object('result','duplicate');
  END IF;
  PERFORM set_config('app.allow_delete', '0', true);
  INSERT INTO public.orders (batch_id, order_number) VALUES (p_batch_id, p_order_number);
  INSERT INTO public.audit_log (event_type, batch_id, order_number, detail)
  VALUES ('scan_added', p_batch_id, p_order_number, jsonb_build_object('source', p_source));
  RETURN jsonb_build_object('result','accepted');
END;
$function$;