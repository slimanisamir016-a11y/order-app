CREATE OR REPLACE FUNCTION public.delete_batch(p_batch_id uuid, p_reason text DEFAULT NULL)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE b public.batches; n int;
BEGIN
  SELECT * INTO b FROM public.batches WHERE id = p_batch_id;
  IF NOT FOUND THEN RETURN jsonb_build_object('result','missing'); END IF;
  SELECT count(*) INTO n FROM public.orders WHERE batch_id = p_batch_id;
  PERFORM set_config('app.allow_delete', '1', true);
  DELETE FROM public.orders WHERE batch_id = p_batch_id;
  UPDATE public.batches SET status = 'open' WHERE id = p_batch_id AND status = 'validated';
  DELETE FROM public.batches WHERE id = p_batch_id;
  PERFORM set_config('app.allow_delete', '0', true);
  INSERT INTO public.audit_log (event_type, batch_id, detail)
  VALUES ('batch_deleted', p_batch_id, jsonb_build_object('code', b.code, 'order_count', n, 'reason', p_reason));
  RETURN jsonb_build_object('result','deleted','code', b.code, 'order_count', n);
END;
$$;

REVOKE ALL ON FUNCTION public.delete_batch(uuid, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.delete_batch(uuid, text) TO service_role;