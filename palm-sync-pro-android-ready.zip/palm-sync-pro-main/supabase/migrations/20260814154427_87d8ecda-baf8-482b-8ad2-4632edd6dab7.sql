ALTER TABLE public.batches ALTER COLUMN code SET DEFAULT upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 4));

ALTER TABLE public.batches DISABLE TRIGGER USER;
UPDATE public.batches SET code = substr(code, 10) WHERE code ~ '^[0-9]{8}-';
ALTER TABLE public.batches ENABLE TRIGGER USER;